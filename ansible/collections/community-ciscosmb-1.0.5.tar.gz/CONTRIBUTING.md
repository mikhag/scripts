# Contributing

Contributions (pull requests, feature requests, and so on) are accepted on project Github.com page. Creating Issue before pull request is preffered. Acceptation is not automatic, project management can reject it, or request changes.

Issues (bugs and feature request) reports are accepted on project Github.

